حارس المقبرة (Graveyard Keeper) — التعريب الكامل — التثبيت اليدوي
تعريب: عبدالله هادي
إصدار التعريب: 1.1.0

هذا التعريب لنسخة Steam، إصدار اللعبة 1.407 (يظهر أسفل الشعار في القائمة الرئيسية: ver. 1.407)، تحديث Steam رقم 26588610 (نسخة 32 بت، نوفمبر 2026). لا يعمل مع النسخ الأقدم.

التثبيت:
1) أغلق اللعبة تماما.
2) في Steam: زر يمين على Graveyard Keeper ← إدارة ← استعراض الملفات المحلية.
3) خذ نسخة احتياطية من الملف:
   Graveyard Keeper_Data\Managed\Assembly-CSharp-firstpass.dll
4) انسخ المجلد Graveyard Keeper_Data من هذا الملف المضغوط والصقه داخل مجلد اللعبة، واختر «استبدال الملفات».
5) شغّل اللعبة: الخيارات (Options) ← اللغة (Language) ← اختر «العربية» (آخر لغة في القائمة).

إلغاء التثبيت:
- أعد ملف Assembly-CSharp-firstpass.dll الأصلي واحذف:
  Graveyard Keeper_Data\Managed\GK1Arabic.dll
  Graveyard Keeper_Data\StreamingAssets\GK1Arabic
- أو في Steam: خصائص ← الملفات المثبتة ← التحقق من سلامة ملفات اللعبة (ثم احذف المجلد GK1Arabic).

الحقوق: هذا التعريب من عمل عبدالله هادي. يمنع إعادة نشره أو نسبه لغير صاحبه. الملفات تحمل بصمة رقمية تثبت مصدرها.

------------------------------------------------------------
Graveyard Keeper — full Arabic translation — manual install
Translation by Abdullah Hadi (عبدالله هادي)
Translation version: 1.1.0

For the Steam version, game version 1.407 (shown under the logo in the main menu), Steam build 26588610 (the 32-bit build, November 2026). It does not work with older builds.

Install:
1) Close the game.
2) Steam: right-click Graveyard Keeper -> Manage -> Browse local files.
3) Back up Graveyard Keeper_Data\Managed\Assembly-CSharp-firstpass.dll
4) Copy the Graveyard Keeper_Data folder from this zip into the game folder and choose Replace.
5) Start the game: Options -> Language -> "العربية" (the last language).

Uninstall: restore the original Assembly-CSharp-firstpass.dll and delete Managed\GK1Arabic.dll and
StreamingAssets\GK1Arabic — or verify the game files in Steam and delete the GK1Arabic folder.

Rights: this translation is the work of Abdullah Hadi. Do not redistribute it or credit it to anyone else.
The files carry a digital fingerprint that proves their origin.
